<div class="nxl-content">
    <!-- [ Main Content ] start -->
    <div class="main-content">
        <div class="row">
           <h4>Settings Mangae Page</h4>
        </div>
    </div>
    <!-- [ Main Content ] end -->
</div>
