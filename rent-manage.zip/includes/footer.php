<!-- [ Footer ] start -->
<footer class="footer">
    <p class="fs-11 text-muted fw-medium text-uppercase mb-0 copyright">
        <span>Copyright ©</span>
        <script>
            document.write(new Date().getFullYear());
        </script>
    </p>
    <p><span>powered by : <a target="_blank" href="https://gsc.co.com"
                target="_blank">GSC</a></span> </p>
    <div class="d-flex align-items-center gap-4">
        <a href="" class="fs-11 fw-semibold text-uppercase">Help</a>
        <a href="" class="fs-11 fw-semibold text-uppercase">Terms</a>
        <a href="" class="fs-11 fw-semibold text-uppercase">Privacy</a>
    </div>
</footer>
<!-- [ Footer ] end -->